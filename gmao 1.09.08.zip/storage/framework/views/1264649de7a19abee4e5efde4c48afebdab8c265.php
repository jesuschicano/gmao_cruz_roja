<?php $__env->startSection('content'); ?>
	<div class="container">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>

	<?php else: ?>
		<h1>Estas son las revisiones del artí­culo <?php echo e($item->equipo); ?></h1>
    <?php if( !isset($revisiones) ): ?>
			<div class="alert alert-warning">
				<strong>Parece que no hay revisiones.</strong> Puedas agregar una nueva pulsando en el botón de añadir.
			</div>
			<a href="/revisiones/create/<?php echo e($item->id); ?>" class="btn btn-primary btn-lg">Añadir</a>
		<?php else: ?>
			<table class="table">
				<thead>
					<th>#</th>
					<th>Descripción</th>
					<th>Grado</th>
					<th>Periodicidad</th>
					<th>Próxima revisión</th>
					<th>Acciones</th>
				</thead>
				<?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($rev->id); ?></td>
						<td><?php echo e($rev->descripcion); ?></td>
						<td><?php echo e($rev->grado); ?></td>
						<td><?php echo e($rev->period); ?> día(s)</td>
						<td><?php echo e($rev->prox_rev); ?></td>
						<td>
							<a href="/revisiones/edit/<?php echo e($rev->id); ?>" class="btn btn-warning">
								<span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
							</a>
							<a href="/revisiones/destroy/<?php echo e($rev->id); ?>" class="btn btn-danger" id="borraRev">
								<span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
			<a href="/revisiones/create/<?php echo e($item->id); ?>" class="btn btn-primary btn-lg">Añadir</a>
    <?php endif; ?>
	<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>