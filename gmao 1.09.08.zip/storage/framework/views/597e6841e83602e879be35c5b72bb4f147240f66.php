<?php $__env->startSection('content'); ?>
	<div class="container-fluid">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>

	<?php else: ?>
		<h1 class="text-center">Listado de revisiones</h1>
		<table class="table" id="misRevisiones">
			<thead>
				<th>Equipo</th>
        <th>Descripción</th>
        <th>Grado</th>
				<th>Departamento</th>
				<th>Última revisión</th>
        <th>Próxima revisión</th>
        <th>Aviso</th>
			</thead>
      <?php $__currentLoopData = $revisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($rev->equipo); ?></td>
          <td><?php echo e($rev->descripcion); ?></td>
          <td><?php echo e($rev->grado); ?></td>
          <td><?php echo e($rev->dname); ?></td>
          <td><?php echo e($rev->ultima_rev); ?></td>
          <td><?php echo e($rev->prox_rev); ?></td>
          <td><?php echo e($rev->aviso); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	<?php endif; ?>
	<a href="<?php echo e(action('RevisionController@download')); ?>" class="btn btn-success">Descargar informe</a>
	</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('funciones'); ?>
  <script>
    $(document).ready(function(){
      $('#misRevisiones').DataTable({
        "language": {
          "sProcessing":     "Procesando...",
          "sLengthMenu":     "Mostrar _MENU_ registros",
          "sZeroRecords":    "No se encontraron resultados",
          "sEmptyTable":     "Ningún dato disponible en esta tabla",
          "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
          "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
          "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
          "sInfoPostFix":    "",
          "sSearch":         "Buscar:",
          "sUrl":            "",
          "sInfoThousands":  ",",
          "sLoadingRecords": "Cargando...",
          "oPaginate": {
              "sFirst":    "Primero",
              "sLast":     "Último",
              "sNext":     "Siguiente",
              "sPrevious": "Anterior"
          },
          "oAria": {
              "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
              "sSortDescending": ": Activar para ordenar la columna de manera descendente"
          }
        }
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>