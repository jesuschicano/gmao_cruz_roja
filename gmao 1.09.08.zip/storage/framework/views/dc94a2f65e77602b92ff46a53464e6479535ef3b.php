<?php $__env->startSection('content'); ?>
	<div class="container">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>

	<?php else: ?>
		<h1>Estos son los proveedores</h1>
		<table class="table table-striped table-bordered">
		<thead>
			<th>Código</th><th>DNI/CIF</th><th>Nombre</th><th>Dirección</th><th>Población</th><th>Provincia</th><th>Teléfono</th><th>Comercial</th><th>Acciones</th>
		</thead>
		<?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($x->codigo); ?></td>
				<td><?php echo e($x->nif); ?></td>
				<td><?php echo e($x->nombre); ?></td>
				<td><?php echo e($x->direccion); ?></td>
				<td><?php echo e($x->poblacion); ?></td>
				<td><?php echo e($x->provincia); ?></td>
				<td><?php echo e($x->telefono); ?></td>
				<td><?php echo e($x->comercial); ?></td>
				<td>
					<a href="/proveedores/editar/<?php echo e($x->id); ?>" class="btn btn-warning">
						<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
					</a>
					<a href="/proveedores/borrar/<?php echo e($x->id); ?>" class="btn btn-danger" id="borraProv">
						<span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
					</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>