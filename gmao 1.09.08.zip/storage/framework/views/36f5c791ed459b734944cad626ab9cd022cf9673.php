<?php $__env->startSection('modalConfirma'); ?>
<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="mi-modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">¿De verdad quiere eliminar este elemento?</h4>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" onclick="ok_hit()">Sí</button>
        <button class="btn btn-danger" aria-hidden="true" data-dismiss="modal">No</button>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->yieldSection(); ?>
