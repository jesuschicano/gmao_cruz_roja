<?php $__env->startSection('content'); ?>
	<div class="container">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>

	<?php else: ?>
		<h1>Estas son las periodicidades que hay configuradas</h1>
		<table class="table table-striped table-bordered">
		<thead>
			<th class="col-sm-1">#</th>
			<th class="col-sm-9">Periodos</th>
			<th class="col-sm-2">Acciones</th>
		</thead>
		<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($x->id); ?></td>
				<td><?php echo e($x->periodicidad); ?> días</td>
				<td>
					<a href="periodicidades/edit/<?php echo e($x->id); ?>" class="btn btn-warning">
						<span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
					</a>
					<a href="periodicidades/destroy/<?php echo e($x->id); ?>" class="btn btn-danger" id="borraPeriod">
						<span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
					</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>