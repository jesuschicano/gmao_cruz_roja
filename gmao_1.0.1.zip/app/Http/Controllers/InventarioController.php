<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Inventario;
// imprescindible agregar el facade DB
use Illuminate\Support\Facades\DB;

class InventarioController extends Controller
{
	public function getIndexOld(){
		// tenemos que conectarnos a otra BD
		// y mostrar los datos que queramos en la query
		$query = DB::connection('mysql2')
						->table('jos_huruhelpdesk_inventory')
						->get();
		return view('inventarioOld', ['items' => $query]);
	}

	public function getIndex(){
		$data = Inventario::all();
		return view('inventario', ['datos'=>$data]);
	}

	public function create(){
		// recogida de los lugares
		$lugares = DB::connection('mysql2')
							->table('jos_huruhelpdesk_places')
							->get();
		// recogida de los departamentos							
		$departamentos = DB::connection('mysql2')
							->table('jos_huruhelpdesk_departments')
							->orderBy('dname','asc')
							->get();
		// recogida de los proveedores
		$proveedores = DB::table('proveedores')->get();
		// recogida de los motivos
		$motivos = DB::table('motivos')->get();
		// recogida de las periodicidades
		$periodicidades = DB::table('periodicidades')->get();

		return view('insertarticuloForm', ['lugares'=>$lugares, 
																'departamentos'=>$departamentos,
																'proveedores'=>$proveedores,
																'motivos'=>$motivos,
																'periodicidades'=>$periodicidades]);
	}

	public function store(Request $request){
		// instanciar
		$item = new Inventario;
		$item->codigo = $request->input();
	}
}
