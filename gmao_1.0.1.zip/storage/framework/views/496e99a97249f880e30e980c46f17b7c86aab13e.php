<?php $__env->startSection('content'); ?>
	<div class="container">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>
         
	<?php else: ?>
		<h1>Estos son los departamentos</h1>
		<?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($x->departamento); ?><br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<a href="<?php echo e(action('DepartamentosController@actualiza')); ?>">Actualizar tabla</a>
	<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>