<?php $__env->startSection('content'); ?>
	<div class="container">
	<?php if(Auth::guest()): ?>
		<div class="col-xs-12 col-md-4 col-md-offset-4">
			<div class="panel panel-danger">
				<div class="panel-heading">Error</div>
				<div class="panel-body">No tienes permiso para estar aquí</div>
			</div>
		</div>
         
	<?php else: ?>
		<h1>Consulta de artículos de GMAO</h1>
		<input type="text" id="filter" onkeyup="buscaEquipo()" placeholder="Búsqueda por equipo..." class="form-control">
		<table class="table" id="itemsHelpdesk">
			<thead>
				<th class="col-sm-1">#</th>
				<th class="col-sm-2">Código</th>
				<th class="col-sm-2">Equipo</th>
				<th class="col-sm-2">Marca</th>
				<th class="col-sm-2">Número serie</th>
				<th class="col-sm-3">Departamento responsable</th>
			</thead>
			<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($x->id); ?></td><td><?php echo e($x->codigo); ?></td><td><?php echo e($x->equipo); ?></td><td><?php echo e($x->marca_fabricante); ?></td><td><?php echo e($x->numero_serie); ?></td><td><?php echo e($x->departamento_responsable); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	<?php endif; ?>
	</div>
	<script type="text/javascript">
		function buscaEquipo()
		{
			var input, filter, table, tr, td, i;
			input = document.getElementById("filter");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("itemsHelpdesk");
		  tr = table.getElementsByTagName("tr");

		  // Loop through all table rows, and hide those who don't match the search query
		  for (i = 0; i < tr.length; i++) {
		    td = tr[i].getElementsByTagName("td")[2];
		    if (td) {
		      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
		        tr[i].style.display = "";
		      } else {
		        tr[i].style.display = "none";
		      }
		    }
		  }//for
		}//buscaEquipo()
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>